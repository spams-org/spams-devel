.onLoad <- function (lib, pkg) {
	library.dynam("spams", pkg, lib)
}
